/*
 * ADC_init.h
 *
 * Created: 9/9/2015 1:32:46 PM
 *  Author: abower
 */ 


#ifndef ADC_INIT_H_
#define ADC_INIT_H_

/* Place any #defines or function prototypes here */
void ADC_init(void);


#endif /* ADC_INIT_H_ */