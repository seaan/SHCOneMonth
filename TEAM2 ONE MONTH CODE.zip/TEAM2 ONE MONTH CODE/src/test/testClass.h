/*
 * testClass.h
 *
 * Created: 9/18/2016 6:29:39 PM
 *  Author: seanw
 */ 
 #include <asf.h>

#ifndef TESTCLASS_H_
#define FLIGHTSTATE_H_

void lightChase(uint8_t delay);

int ADC_test(uint8_t msDelay);

void test(void);

#endif /* TESTCLASS_H_ */