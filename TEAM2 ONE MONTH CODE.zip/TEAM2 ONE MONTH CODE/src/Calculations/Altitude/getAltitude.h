/*
 * altitudeMeasurement.h
 *
 * Created: 9/20/2016 11:17:22 PM
 *  Author: seanw
 */ 
#include <asf.h>

#ifndef GETALTITUDE_H_
#define GETALTITUDE_H_

float getAltitude(void);

#endif /* GETALTITUDE_H_*/