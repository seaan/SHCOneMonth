/*
 * getPressure.h
 *
 * Created: 9/22/2016 11:45:14 AM
 *  Author: seanw
 */ 

//TEMPLATE FROM GITHUB, PROTOTYPING..
#ifndef GETPRESSURE_H_
#define GETPRESSURE_H_

float getPressure(void);

#endif /* GETPRESSURE_H_ */