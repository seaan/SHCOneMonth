/*
 * getPressure.c
 *
 * Created: 9/22/2016 11:45:21 AM
 *  Author: seanw
 */
 #include <asf.h>
 #include "Drivers/Pressure/getPressure.h"
 float getPressure(void){
	 
	 return 0;
}