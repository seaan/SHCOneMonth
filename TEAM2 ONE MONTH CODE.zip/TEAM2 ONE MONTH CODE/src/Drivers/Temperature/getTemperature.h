/*
 * getTemperature.h
 *
 * Created: 9/22/2016 11:48:17 AM
 *  Author: seanw
 */ 

#ifndef GETTEMPERATURE_H_
#define GETTEMPERATURE_H_

float getTemperature(void);



#endif /* GETTEMPERATURE_H_ */