/*
 * Motor_driver.h
 *
 * Created: 9/25/2016 9:16:14 PM
 *  Author: seanw
 */ 


#ifndef MOTOR_DRIVER_H_
#define MOTOR_DRIVER_H_

void motor(uint16_t period);



#endif /* MOTOR_DRIVER_H_ */