/*
 * Buzzer_Driver.h
 *
 * Created: 9/25/2016 9:15:58 PM
 *  Author: seanw
 */ 


#ifndef BUZZER_DRIVER_H_
#define BUZZER_DRIVER_H_

void buzzer(uint16_t period);

/* Music methods */
//void setup();
//void playMusic(int songLength, int* beats, int tempo, char* notes);
//int frequency(char note);

#endif /* BUZZER_DRIVER_H_ */