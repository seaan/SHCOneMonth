/*
 * LED_driver.h
 *
 * Created: 9/25/2016 9:15:31 PM
 *  Author: seanw
 */ 


#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_

void LED(uint16_t period,uint8_t duty_cycle);



#endif /* LED_DRIVER_H_ */